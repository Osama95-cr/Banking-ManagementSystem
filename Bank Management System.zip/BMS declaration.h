/* This Project covers the following topics:
Inheritance
Polymorphism
Method Overriding
Abstract Classes
Pure Virtual Functions
This Pointer "->"
Dynamic Binding*/

#include<iostream>
#include<string>
#include<fstream>
using namespace std;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
														//ACCOUNT CLASS
class Account		//Abstract Class
{
protected:
	int ac_no;
	string name;
	string CNIC;
	string Mother_name;
	string DOB;
	float total_amount;
	int code;
	float present_loan;
public:
	fstream fs;
	Account()
	{ present_loan=0; }

	float loan_taken;
	float loan_returned;

	void create_ac();	     //Create Account
	void Deposit();		    //Money Deposit
	void Withdraw();	   //Money Withdraw

	virtual void Return_Loan() = 0;		//Return Loan (Pure Virtual Function)
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
													//CHECKING ACCOUNT CLASS
class Checking_Account : public Account
{
public:
	void show_ac();		//Show Account
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
														//LOAN CLASS
class Loan : public Checking_Account
{
public:
	void Get_Loan();		//Take Loan
	void Return_Loan();		//Overriding
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
													//SAVING ACCOUNT CLASS
class savingaccount :public Loan
{
public:
	void saving_acc();
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
														//CUSTOMER CLASS
class customer: public savingaccount
{
public:
};