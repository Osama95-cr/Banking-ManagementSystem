#include "BMS.h"

int main()
{
	Account *B;
	customer foo;
	B=&foo;		//Polymorphism through Dynamic Binding

	char c;
	int ch;

	do
	{
		system("cls");
		cout<<"\t\tBANKING SYSTEM "<<endl;
		cout<<"\t\t 1. Create account "<<endl;
		cout<<"\t\t 2. Show Account "<<endl;
		cout<<"\t\t 3. Saving account"<<endl;
		cout<<"\t\t 4. Deposit amount "<<endl;
		cout<<"\t\t 5. Withdraw amount "<<endl;
		cout<<"\t\t 6. Take loan "<<endl;
		cout<<"\t\t 7. Return loan "<<endl;
		cout<<"\t\t 8. Exit "<<endl;

		cin>>ch;
		switch (ch)
		{
		case 1:
			{
				foo.create_ac();
				break;
			}
		case 2:
			{
				foo.show_ac();
				break;
			}
		case 3:                                
			{
				foo.saving_acc();
				break;
			}
		case 4:
			{
				foo.Deposit();
				break;
			}
		case 5:
			{
				foo.Withdraw();
				break;
			}
		case 6:
			{
				foo.Get_Loan();
				break;

			}
		case 7:
			{
				B->Return_Loan();
				break;
			}
		case 8:
			{
				cout<<"Exiting"<<endl;
				break;
			}
		default:
			cout<<"Wrong selection"<<endl;
		}

		cout<<"Do you want to use it again (y/n)"<<endl;
		cin>>c;
	}

	while (c=='y'|| c=='Y');

	system ("pause");
	return 0;
}



