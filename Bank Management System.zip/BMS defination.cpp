#include "BMS.h"

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void Account::create_ac()
{
	cout<<"Enter account holder name ";
	cin.ignore();
	cin >> name;
	cout<<"Enter mother name ";
	cin >> Mother_name;
	cout<<"Enter your Date of Birth (dd-mm-yy) ";
	cin >> DOB;
	cout<<"Enter CNIC no ";
	cin>>CNIC;
	cout<<"Enter Account number ";
	cin>>ac_no;
	cout<<"Enter digits code for your account  ";   //Password
	cin>>code;
	cout<<"Minimum initial amount should be RS 50,000. Enter initial amount ";
	cin>>total_amount;
	while(total_amount<0 || total_amount<50000)
	{
		cout<<"Not valid entry"<<endl;
		cout<<"Enter again: ";
		cin>>total_amount;
	}

	fs.open("BMS.txt", ios::out | ios::app);
	fs << name << "." << Mother_name << "." << DOB << "." << CNIC << "." << "." << "." << total_amount << endl;
	fs.close();

	cout<<"Thanks for creating account"<<endl;
}

void Account :: Deposit()
{
	string m,n,mm;
	float deposit;
	cout<<"What is your mother's name: "<<endl;
	cin>>m;

	if(m==Mother_name)
	{
		cout<<"Enter your Date of Birth"<<endl;
		cin>>n;

		if (n==DOB)
		{
			cout<<"Enter your CNIC"<<endl;
			cin>>mm;
			if (mm==CNIC)
			{
				cout<<"Enter money to deposit "<<endl;
				cin>>deposit;

				while (deposit<0)
				{
					cout<<"Enter value greater than zero"<<endl;
					cin>>deposit;
				}

				total_amount =total_amount + deposit;
				cout<<"Deposit successful"<<endl;

				fs.open("BMS.txt", ios::out | ios::app);
				fs << name << "." << Mother_name << "." << DOB << "." << CNIC << "." << "." << "." << total_amount << endl;
				fs.close();
			}
			else
				cout<<"Wrong CNIC entered"<<endl;
		}
		else
			cout<<"Wrong DOB entered"<<endl;
	}
	else
		cout<<"Wrong Mother name entered"<<endl;
}

void Account :: Withdraw()
{
	string ps,ds,pps;
	float withdraw;
	cout<<"Enter your mother's name "<<endl;
	cin>>ps;

	if (ps==Mother_name)
	{
		cout<<"Enter your Date of Birth "<<endl;
		cin>>ds;

		if (ds==DOB)
		{
			cout<<"Enter your CNIC "<<endl;
			cin>>pps;

			if (pps==CNIC)
			{
				cout<<"Enter money to withdraw "<<endl;
				cin>>withdraw;

				while (withdraw<0 || withdraw>total_amount)
				{
					cout<<"Either value is less than zero OR You don't have enough Balance"<<endl;
					cout<<"ReEnter Withdraw amount "<<endl;
					cin>>withdraw;
				}

				total_amount=total_amount-withdraw;
				cout<<"Withdraw successfull"<<endl;

				fs.open("BMS.txt", ios::out | ios::app);
				fs << name << "." << Mother_name << "." << DOB << "." << CNIC << "." << "." << "." << total_amount << endl;
				fs.close();
			}

			else
				cout<<"Wrong CNIC entered"<<endl;
		}

		else
			cout<<"Wrong DOB entered"<<endl;
	}
	else
		cout<<"Wrong Mother Name entered"<<endl;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void Checking_Account :: show_ac()
{
	string c,w,ww;
	cout<<"Enter your mother's name. "<<endl;
	cin>>w;

	if (w==Mother_name)
	{
		cout<<"Enter your date of birth "<<endl;
		cin>>c;

		if (c==DOB)
		{
			cout<<"Enter your CNIC to view account"<<endl;
			cin>> ww;

			if (ww==CNIC)
			{
				cout<<"Account number: "<<ac_no<<endl;
				cout<<"Account owner's name: "<<name<<endl;
				cout<<"Mother Name: "<<Mother_name<<endl;
				cout<<"Date of Birth: "<<DOB<<endl;
				cout<<"Owner's CNIC no: "<<CNIC<<endl;
				cout<<"Bank Balance RS: "<<total_amount<<endl;
			}

			else
				cout<<"Wrong CNIC Entered"<<endl;
		}
		else
			cout<<"Wrong DOB Entered"<<endl;
	}
	else
		cout<<"Wrong Mother Name entered"<<endl;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void Loan :: Get_Loan()	
{
	string zz, xx,yy;
	cout<<"Enter your mother's name "<<endl;
	cin>>zz;

	if (zz==Mother_name)
	{
		cout<<"Enter your Date of Birth "<<endl;
		cin>>xx;

		if (xx==DOB)
		{
			cout<<"Enter your CNIC "<<endl;
			cin>>yy;

			if (yy==CNIC)
			{
				cout<<"The max loan which you can take from bank is RS 10,00,000"<<endl;
				cout<<"Right now, you can take loan from RS 10,000 to RS 500000"<<endl;
				cout<<"How much loan do you want: "<<endl;
				cin>>loan_taken;

				while (loan_taken<0)
				{
					cout<<"Enter value greater than zero"<<endl;
					cin>>loan_taken;
				}

				if(present_loan<1000000)
				{
					if( loan_taken>=10000 && loan_taken<=500000)
					{
						present_loan = present_loan + loan_taken;
						total_amount = total_amount + loan_taken;
						cout<<"Loan added to your account succesfully"<<endl;

						fs.open("BMS.txt", ios::out | ios::app);
						fs << name << "." << Mother_name << "." << DOB << "." << CNIC << "." << "." << "." << total_amount << endl;
						fs.close();
					}
					else
						cout<<"You can only take loan from RS 10,000 to RS 500000"<<endl;
				}
				else cout<<"You can not take loan from bank more than RS 10,00,000"<<endl;
			}
			else
				cout<<"Wrong CNIC entered"<<endl;
		}
		else
			cout<<"Wrong DOB entered"<<endl;
	}
	else
		cout<<"Wrong Mother name entered"<<endl;
}

void Loan :: Return_Loan()
{
	string m,n,nn;
	cout<<"Enter Mother's name: "<<endl;
	cin>>m;

	if(m==Mother_name)
	{
		cout<<"Enter your Date of Birth"<<endl;
		cin>>n;

		if (n==DOB)
		{
			cout<<"Enter your CNIC"<<endl;
			cin>>nn;

			if (nn==CNIC)
			{
				if(loan_taken>0)
				{
					cout<<"Your present loan is RS"<<present_loan<<endl;
					cout<<"How much money you want to return to bank? : "<<endl;
					cin>>loan_returned;

					while(loan_returned> present_loan)
					{
						cout<<"Either you are entering the value greater than your initial loan, or you have no loan"<<endl;
						cout<<"Enter again"<<endl;
						cin>>loan_returned;
					}

					total_amount = total_amount - loan_returned;
					present_loan = present_loan - loan_returned;
					cout<<"You returned "<<loan_returned<<" RS. Thankyou"<<endl;
					cout<<"Now your remaining loan is RS:"<<present_loan<<endl;

					fs.open("BMS.txt", ios::out | ios::app);
					fs << name << "." << Mother_name << "." << DOB << "." << CNIC << "." << "." << "." << total_amount << endl;
					fs.close();
				}

				else
					cout<<"You don't have any loan"<<endl;
			}
			else
				cout<<"Wrong CNIC entered"<<endl;
		}
		else
			cout<<"Wrong DOB entered"<<endl;
	}
	else
		cout<<"Wrong Mother name entered"<<endl;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void savingaccount :: saving_acc()
{
	string alpha, bravo,charlie;
	cout<<"Enter your mother's name "<<endl;
	cin>>alpha;

	if(alpha==Mother_name)
	{
		cout<<"Enter your Date of Birth "<<endl;
		cin>>bravo;

		if (bravo==DOB)
		{
			cout<<"Enter your CNIC "<<endl;
			cin>>charlie;

			if (charlie==CNIC)
			{
				float interest_rate=1.1;
				total_amount=total_amount*interest_rate;
				cout<<"Profit is 10% of the actual amount available in bank account:"<<endl;
				cout<<"Total amount in saving account after an year is :"<<total_amount<<endl;
				fs.open("BMS.txt", ios::out | ios::app);
				fs << name << "." << Mother_name << "." << DOB << "." << CNIC << "." << "." << "." << total_amount << endl;
				fs.close();
			}
			else
				cout<<"Wrong CNIC entered"<<endl;
		}
		else
			cout<<"Wrong DOB entered"<<endl;
	}
	else
		cout<<"Wrong Mother name entered"<<endl;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
